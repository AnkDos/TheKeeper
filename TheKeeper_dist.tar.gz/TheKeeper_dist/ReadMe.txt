Hello Everyone!
The keeper is a note keeper that saves your note offline and it could be acessed online.

the notes are saved in :

offline:

/home/username/keeper (Linux)

online :

https://westphalian-prisms.000webhostapp.com/?id="yourfilename.txt"


Requirment:

jre-8


To run:

java -jar "/location/TheKeeper.jar"

---------
For any queries ,Email:
ankurpan96@gmail.com